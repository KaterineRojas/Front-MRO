import { Article } from '../components/features/inventory/types/inventory';

const URL = 'http://localhost:5000/api';

// --- Interfaz para los Datos del Item sin la imagen (la imagen va aparte en FormData) ---
interface ItemPayload {
  name: string;
  description: string;
  category: string;
  unit: string;
  minStock: number;
  consumible: boolean;
  // Nota: 'urlImage' NO va aquí, ya que el back-end la genera.
}

// --- Función Auxiliar para Obtener el Token ---
const getAuthToken = (): string | null => {
 //verificar
  return localStorage.getItem('authToken'); 
};

// --- GET ITEMS (Mantengo tu función existente) ---
export async function getItems(): Promise<Article[]> {
  const response = await fetch(`${URL}/items`);
  if (!response.ok) {
    throw new Error('Error al obtener los artículos');
  }
  return await response.json();
}

// --- SAVE ITEMS (Mantengo tu función existente) ---
export async function saveItems(items: Article[]): Promise<any> {
  
  console.log(' JSON ', items);
 
  const authToken = getAuthToken();

  if (!authToken) {
  
    throw new Error('No se encontró el token de autenticación. Inicie sesión.');
  }

console.log(' JSON de artículos recibido en saveItems:', items);

  const requestOptions: RequestInit = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`, 
    },
    body: JSON.stringify(items), 
  };

  const response = await fetch(`${URL}/Items`, requestOptions); 

  if (!response.ok) {
  
    const errorBody = await response.text(); 
    throw new Error(`Error ${response.status} al guardar artículos: ${errorBody || response.statusText}`);
  }

  return await response.json(); 
}

// ---------------------------------------------------------------------------------------
// --- NUEVO MÉTODO PARA CREAR ITEM CON IMAGEN (multipart/form-data) ---
// ---------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------
// --- NUEVO MÉTODO PARA CREAR ITEM CON IMAGEN (SIN TOKEN) ---
// ---------------------------------------------------------------------------------------

interface CreateItemWithImagePayload extends ItemPayload {
    imageFile: File;
}

export async function createItemWithImage(payload: CreateItemWithImagePayload): Promise<Article> {
    
    const { imageFile, ...itemData } = payload; 
    const endpoint = `${URL}/Items/with-image`;
    const formData = new FormData();

    formData.append('file', imageFile); 
    
    for (const key in itemData) {
        if (Object.prototype.hasOwnProperty.call(itemData, key)) {
            formData.append(key, String((itemData as any)[key])); 
        }
    }

    // 4. Configurar las opciones de la petición
    const requestOptions: RequestInit = {
        method: 'POST',
        body: formData, 
    };

    // 5. Enviar la petición
    console.log("service",endpoint, requestOptions);
    const response = await fetch(endpoint, requestOptions); 

    if (!response.ok) {
        const errorBody = await response.text(); 
        throw new Error(`Error ${response.status} al crear ítem con imagen: ${errorBody || response.statusText}`);
    }

    return await response.json() as Article; 
}