import React from 'react';
import { BinManager } from '../components/BinManager';
export function BinsTab() {
  return <BinManager />;
}
