import React from 'react';
import { InventoryMovements } from '../../../InventoryMovements';

export function TransactionsTab() {
  return <InventoryMovements />;
}
